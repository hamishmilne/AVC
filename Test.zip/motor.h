#include "E101.h"

class Motor {
    unsigned char num;              //Motor num 
    unsigned char pwm;              //Motor speed 
    bool left;                      //Is the motor on the left or right?

    public:
        Motor();                    //Dont use
        Motor(unsigned char motor_num, unsigned char motor_speed, bool motor_left);
        void forward();
        void back();
        void stop();
};