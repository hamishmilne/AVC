#include "motor.h"

class Robot {
    Motor left;                     //Left motor
    Motor right;                    //Right motor
    
    public:
        Robot();                    //Dont use
        Robot(Motor motor_left, Motor motor_right);
        void startLeft();
        void startRight();
        void startForward();
        void stop();
};