#include "robot.h"

Robot::Robot(Motor motor_left, Motor motor_right) {
    left = motor_left;
    right = motor_right;

    //Create camera here etc
}

//Moves both motors forward
void Robot::startForward() {
    left.forward();
    right.forward();
}

//Moves robot left
void Robot::startLeft() {
    left.back();
    right.forward();
}

//Moves robot right
void Robot::startRight() {
    left.forward();
    right.back();
}

//Stop robot
void Robot::stop() {
    left.stop();
    right.stop();
}