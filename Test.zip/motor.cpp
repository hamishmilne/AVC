#include "motor.h"

//Motor constructer, usage: Motor m(num, pwn);
Motor::Motor(unsigned char motor_num, unsigned char motor_speed, bool motor_left) {
    num = motor_num;
    pwm = motor_speed;
    left = motor_left;
    set_motors(num, pwm);
    hardware_exchange();
}

//Move motor forward
void Motor::forward() {
    //If a motor is on the left or right sight it should move in the reverse direction to the other
    if(left) {
        pwm = 65;
    }else{
        pwm = 30;
    }
    set_motors(num, pwm);
    hardware_exchange();
}

//Move motor backwards
void Motor::back() {
    //If a motor is on the left or right sight it should move in the reverse direction to the other
    if(left) {
        pwm = 30;
    }else{
        pwm = 65;
    }
    set_motors(num, pwm);
    hardware_exchange();
}

//Stop motor
void Motor::stop() {
    pwm = 48;
    set_motors(num, pwm);
    hardware_exchange();
}